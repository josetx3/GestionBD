class InvoiceJs {

    consultClientInvoice() {
        var cl_nombre = document.querySelector('#cliente_nombre');
        var cl_documento = document.querySelector('#cliente_documento');
        var cl_nit_negocio = document.querySelector('#cliente_nit_negocio');
        var cl_nombre_negocio = document.querySelector('#cliente_nombre_negocio');
        var documento = document.getElementById("consult_client_invoice").value;
        var object = new FormData();
        object.append("documento", documento);
        fetch("InvoiceController/consultClientInvoice", {
            method: "POST",
            body: object,
        })
            .then((respuesta) => respuesta.text())
            .then(function (response) {
                try {
                    object = JSON.parse(response);
                    var cliente_nombre = "";
                    var cliente_documento = "";
                    var cliente_nit_negocio = "";
                    var cliente_nombre_negocio = "";
                    object.forEach(cliente => {
                        cliente_nombre = '<input type="text" class="form-control" value= "' + cliente.cliente_nombre + '" required readOnly>'
                        cliente_documento = '<input type="text" class="form-control" value= "' + cliente.cliente_documento + '" required readOnly>'
                        cliente_nit_negocio = '<input type="text" class="form-control" value= "' + cliente.cliente_nit_negocio + '" required readOnly>'
                        cliente_nombre_negocio = '<input type="text" class="form-control" value= "' + cliente.cliente_nombre_negocio + '" required readOnly>'


                    });
                    cl_nombre.innerHTML = cliente_nombre;
                    cl_documento.innerHTML = cliente_documento;
                    cl_nit_negocio.innerHTML = cliente_nit_negocio;
                    cl_nombre_negocio.innerHTML = cliente_nombre_negocio;
                    console.log(cliente_nombre + " |-|-|-| " + cliente_documento + " |-|-|-| " + cliente_nit_negocio + " |-|-|-| " + cliente_nombre_negocio);
                } catch (error) {
                    document.querySelector("#content").innerHTML = response;
                }
            })
            .catch(function (error) {
                console.log(error);
            });
    }

    aggProduct() {

    }

}
var Invoice = new InvoiceJs();

var cont_factura = "";


// https://fb.watch/hnCf35G5UY/