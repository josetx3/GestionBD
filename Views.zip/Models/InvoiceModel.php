<?php

class InvoiceModel
{
    private $Connection;
    function __construct($Connection)
    {
        $this->Connection = $Connection;
    }

    function consultClientInvoice($search_client)
    {
        $sql = "SELECT * FROM cliente WHERE cliente_documento = '$search_client' OR cliente_nit_negocio = '$search_client'";
        $this->Connection->query($sql);
        return $this->Connection->fetchAll();
    }

    function aggProduct($aggProduct)
    {
        $sql = "SELECT * FROM produc WHERE prod_reference = '$aggProduct' OR prod_code_plu = '$aggProduct'";
        $this->Connection->query($sql);
        return $this->Connection->fetchAll();
    }
}
