<?php
class InvoiceView
{

    function paginateInvoice($array_products)
    {
?>
        <div class="cord">
            <div class="card-header text-center bg-info text-black">
                Registrar una factura
            </div>
            <br>
            <div class="card-body">
                <form id="insert-invoice">
                    <br>

                    <label for="">Buscar cliente</label>
                    <div class="search-bar">
                        <form id="form_C_invoice" class="search-form align-items-center" method="POST" action="#">
                            <div class="row mb-10">
                                <div class="col-md-10">
                                    <input class="form-control" type="text" name="consult_client_invoice" id="consult_client_invoice" placeholder="Busqueda por documento | nit negocio" title="Busqueda por documento | nit negocio">
                                </div>
                                <div class="col-md-1">
                                    <button class="form-control " type="button" title="Buscar"><i class="bi bi-search" onclick="Invoice.consultClientInvoice()"></i></button>
                                </div>
                                <div class="col-md-1">
                                    <button class="form-control " type="button" title="Recargar"><i class="bi bi-arrow-counterclockwise" onclick="Menu.menu('InvoiceController/paginateInvoice')"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
            </div>

            <br>
            <hr>
            <br>

            <div class="row md-12 text-justify">

                <div class="form-group col-md-3">
                    <label for="">NOMBRE CLIENTE</label>
                    <div class="form-group md-12" id="cliente_nombre">
                    </div>
                </div>

                <div class="form-group col-md-3">
                    <label for="">DOCUMENTO CLIENTE</label>
                    <div class="form-group md-12" id="cliente_documento">
                    </div>
                </div>

                <div class="form-group col-md-3">
                    <label for="">NIT NEGOCIO</label>
                    <div class="form-group md-12" id="cliente_nit_negocio">
                    </div>
                </div>

                <div class="form-group col-md-3">
                    <label for="">NOMBRE NEGOCIO</label>
                    <div class="form-group md-12" id="cliente_nombre_negocio">
                    </div>
                </div>

            </div>

            <br>
            <hr>
            <br>
            <div class="search-bar">
                <form id="form_aa_prodcut" class="search-form align-items-center" method="POST" action="#">
                    <div class="row col-12">
                        <div class="col-8">
                            <label for="">Productos:</label>
                            <select class="form-select" name="emti_id" id="emti_id">
                                <option value="">Seleccione...</option>
                                <?php
                                if ($array_products) {
                                    foreach ($array_products as $object_product) {
                                        $prod_reference = $object_product->prod_reference;
                                        $prod_code_plu = $object_product->prod_code_plu;
                                        $prod_description = $object_product->prod_description;
                                        $prod_available_quantity = $object_product->prod_available_quantity;
                                        $prod_arrival_price = $object_product->prod_arrival_price;
                                        $prod_selling_price = $object_product->prod_selling_price;
                                        $prod_iva = $object_product->prod_iva;
                                ?>
                                        <option value="<?= $prod_reference; ?>"><?= $prod_description; ?></option>
                                <?php
                                    }
                                }
                                ?>
                            </select>
                        </div>

                        <div class="col-1">
                            <label for="">Cantidad</label>
                            <input class="form-control" name="cantidad" id="cantidad" type="text">
                        </div>
                        <div class="col-1">
                            <!-- <button class="form-control " type="button" title="Buscar"><i class="bi bi-basket2-fill" onclick="Invoice.aggProduct()"></i></button> -->
                            <i class="bi bi-basket2-fill" onclick="Person.aggProduct('<?= $prod_reference ?>')"></i>
                        </div>
                    </div>
                </form>
            </div>
            <br>
            <hr>

            <div class="row md-12 text-justify align-items-center" id="contenido_fac">

                <!-- ACA SE PEGA LO QUE TRAE DEL JS -->


            </div>

            <br>
            <hr><br>
            <div class="row md-12">

                <div class="row col-12 text-justify">
                    <br>
                    <div class="row text-justify col-md-4">
                        <div class="form-group ">
                            <label for="" class="">SUBTOTAL :</label>
                            <input type="text" class="form-control" name="" id="" required>
                        </div>
                    </div>

                    <div class="row text-justify col-md-4">
                        <div class="form-group ">
                            <label for="" class="">I.V.A :</label>
                            <input type="text" class="form-control" name="" id="" required>
                        </div>
                    </div>

                    <div class="row text-justify col-md-4">
                        <div class="form-group ">
                            <label for="" class="">TOTAL NETO :</label>
                            <input type="text" class="form-control" name="" id="" required>
                        </div>
                    </div>
                    <br>

                </div>
            </div>
        </div>

        </form>
        </div>
        </div>
<?php
    }
}
