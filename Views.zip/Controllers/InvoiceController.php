<?php
require_once "Models/InvoiceModel.php";
require_once "Views/InvoiceView.php";

class InvoiceController
{
    function paginateInvoice()
    {
        require_once "Models/ProductModel.php";
        $Connection = new Connection('sel');
        $InvoiceModel = new InvoiceModel($Connection);
        $ProductModel = new ProductModel($Connection);
        $InvoiceView = new InvoiceView();
        $array_products = $ProductModel->listProduct();

        $InvoiceView->paginateInvoice($array_products);
    }

    function consultClientInvoice()
    {
        $Connection = new Connection('sel');
        $InvoiceModel = new InvoiceModel($Connection);
        $InvoiceView = new InvoiceView();

        $search_client = $_POST['documento'];

        if (empty($search_client)) {
            $response = ["message" => 'INGRESE UN VALOR PARA REALIZAR LA BUSQUEDA'];
            exit(json_encode($response));
        }

        $array_consult_client_invoice = $InvoiceModel->consultClientInvoice($search_client);

        if (!$array_consult_client_invoice) {
            $response = ["message" => 'NO SE ENCUENTRA REGISTRADO O ESTAN MAL LOS VALORES'];
            exit(json_encode($response));
        }
        echo (json_encode($array_consult_client_invoice));

        

    }

    function aggProduct()
    {
        $Connection = new Connection('sel');
        $InvoiceModel = new InvoiceModel($Connection);
        $InvoiceView = new InvoiceView();

        $aggProduct = $_POST['product'];

        if (empty($aggProduct)) {
            $response = ["message" => 'INGRESE UN VALOR PARA AGREGAR UN PRODUCTO'];
            exit(json_encode($response));
        }

        $array_agg_product = $InvoiceModel->aggProduct($aggProduct);

        if (!$array_agg_product) {
            $response = ["message" => 'NO SE ENCUENTRA REGISTRADO O ESTAN MAL LOS VALORES'];
            exit(json_encode($response));
        }
        echo (json_encode($array_agg_product));
    }
}
